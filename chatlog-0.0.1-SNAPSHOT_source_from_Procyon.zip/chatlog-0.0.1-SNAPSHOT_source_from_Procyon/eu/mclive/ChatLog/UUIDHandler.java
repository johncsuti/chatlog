// 
// Decompiled by Procyon v0.5.36
// 

package eu.mclive.ChatLog;

import java.util.UUID;
import org.bukkit.entity.Player;
import java.io.IOException;
import org.json.simple.parser.ParseException;
import java.io.Reader;
import java.io.InputStreamReader;
import org.json.simple.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import org.json.simple.parser.JSONParser;
import org.bukkit.Bukkit;
import org.bukkit.event.Listener;

public class UUIDHandler implements Listener
{
    private ChatLog plugin;
    
    public UUIDHandler(final ChatLog plugin) {
        this.plugin = plugin;
    }
    
    public String getUUID(final String player) {
        final Player p = Bukkit.getServer().getPlayer(player);
        if (p != null) {
            final UUID uuid = Bukkit.getServer().getPlayer(player).getUniqueId();
            this.plugin.logger.info(p.getName() + " is online! UUID: " + uuid.toString().replace("-", ""));
            return uuid.toString().replace("-", "");
        }
        this.plugin.logger.info(player + " is offline! Fetching UUID from api.minetools.eu");
        final JSONParser jsonParser = new JSONParser();
        try {
            final HttpURLConnection connection = (HttpURLConnection)new URL("http://api.minetools.eu/uuid/" + player).openConnection();
            try {
                final JSONObject response = (JSONObject)jsonParser.parse((Reader)new InputStreamReader(connection.getInputStream()));
                final String uuid2 = (String)response.get((Object)"uuid");
                if (uuid2.length() > 4) {
                    this.plugin.logger.info("UUID from " + player + ": " + uuid2.replace("-", ""));
                    return uuid2.replace("-", "");
                }
                this.plugin.logger.info("Minetools returned null! " + player + " is no premium user!");
                return null;
            }
            catch (ParseException e) {
                e.printStackTrace();
            }
        }
        catch (IOException e2) {
            e2.printStackTrace();
        }
        return null;
    }
}
