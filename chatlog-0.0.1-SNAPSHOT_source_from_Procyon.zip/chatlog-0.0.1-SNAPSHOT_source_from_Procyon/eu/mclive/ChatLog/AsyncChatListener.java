// 
// Decompiled by Procyon v0.5.36
// 

package eu.mclive.ChatLog;

import org.bukkit.event.EventPriority;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.Listener;

public class AsyncChatListener implements Listener
{
    private ChatLog plugin;
    
    public AsyncChatListener(final ChatLog plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onAsyncPlayerChat(final AsyncPlayerChatEvent e) {
        if (e.isCancelled()) {
            return;
        }
        this.plugin.getUtils().logMessage(e.getPlayer(), e.getMessage());
    }
}
