// 
// Decompiled by Procyon v0.5.36
// 

package eu.mclive.ChatLog.update;

import org.bukkit.ChatColor;
import java.io.IOException;
import java.net.MalformedURLException;
import org.json.simple.parser.ParseException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.bukkit.entity.Player;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.plugin.Plugin;
import java.util.UUID;

public class UpdateUtil
{
    public static final String PREFIX;
    private static final String URL = "http://api.spiget.org/v2/resources/";
    private static final int PLUGIN = 1128;
    private static final String LATEST_VERSION = "/versions/latest";
    
    public static void sendUpdateMessage(final UUID uuid, final Plugin plugin) {
        new BukkitRunnable() {
            public void run() {
                final String message = getUpdateMessage(false, plugin);
                if (message != null) {
                    new BukkitRunnable() {
                        public void run() {
                            final Player p = Bukkit.getPlayer(uuid);
                            if (p != null) {
                                p.sendMessage(UpdateUtil.PREFIX + message);
                            }
                        }
                    }.runTask(plugin);
                }
            }
        }.runTaskAsynchronously(plugin);
    }
    
    public static void sendUpdateMessage(final Plugin plugin) {
        new BukkitRunnable() {
            public void run() {
                final String message = getUpdateMessage(true, plugin);
                if (message != null) {
                    new BukkitRunnable() {
                        public void run() {
                            plugin.getLogger().warning(message);
                        }
                    }.runTask(plugin);
                }
            }
        }.runTaskAsynchronously(plugin);
    }
    
    private static String getUpdateMessage(final boolean console, final Plugin plugin) {
        if (plugin.getDescription().getVersion().equals("${project.version}")) {
            return "You are using a debug/custom version, consider updating.";
        }
        final String newestString = getNewestVersion(plugin);
        if (newestString == null) {
            if (console) {
                return "Could not check for updates, check your connection.";
            }
            return null;
        }
        else {
            Version current;
            try {
                current = new Version(plugin.getDescription().getVersion());
            }
            catch (IllegalArgumentException e) {
                return "You are using a custom version, consider updating.";
            }
            final Version newest = new Version(newestString);
            if (current.compareTo(newest) < 0) {
                return "There is a newer version available: " + newest.toString() + ", you're on: " + current.toString();
            }
            if (!console || current.compareTo(newest) == 0) {
                return null;
            }
            if (current.getTag().toLowerCase().startsWith("dev") || current.getTag().toLowerCase().startsWith("snapshot")) {
                return "You are running a development version, please report any bugs to GitHub.";
            }
            return "You are running a newer version than is released!";
        }
    }
    
    private static String getNewestVersion(final Plugin plugin) {
        try {
            final URL url = new URL("http://api.spiget.org/v2/resources/1128/versions/latest?" + System.currentTimeMillis());
            final HttpURLConnection connection = (HttpURLConnection)url.openConnection();
            connection.setUseCaches(true);
            connection.addRequestProperty("User-Agent", "ChatLog " + plugin.getDescription().getVersion());
            connection.setDoOutput(true);
            final BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String content = "";
            String input;
            while ((input = br.readLine()) != null) {
                content += input;
            }
            br.close();
            final JSONParser parser = new JSONParser();
            JSONObject statistics;
            try {
                statistics = (JSONObject)parser.parse(content);
            }
            catch (ParseException e) {
                e.printStackTrace();
                return null;
            }
            return (String)statistics.get((Object)"name");
        }
        catch (MalformedURLException e2) {
            return null;
        }
        catch (IOException e3) {
            return null;
        }
    }
    
    static {
        PREFIX = ChatColor.GREEN + "" + ChatColor.BOLD + "[ChatLog] " + ChatColor.GREEN;
    }
}
