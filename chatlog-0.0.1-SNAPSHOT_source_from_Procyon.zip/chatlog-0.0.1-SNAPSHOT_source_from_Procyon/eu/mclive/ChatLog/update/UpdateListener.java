// 
// Decompiled by Procyon v0.5.36
// 

package eu.mclive.ChatLog.update;

import org.bukkit.event.EventHandler;
import org.bukkit.plugin.Plugin;
import org.bukkit.event.player.PlayerJoinEvent;
import eu.mclive.ChatLog.ChatLog;
import org.bukkit.event.Listener;

public class UpdateListener implements Listener
{
    private final ChatLog plugin;
    
    public UpdateListener(final ChatLog plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onJoin(final PlayerJoinEvent e) {
        if (e.getPlayer().hasPermission("chatlog.update")) {
            UpdateUtil.sendUpdateMessage(e.getPlayer().getUniqueId(), (Plugin)this.plugin);
        }
    }
}
