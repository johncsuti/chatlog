// 
// Decompiled by Procyon v0.5.36
// 

package eu.mclive.ChatLog.Commands;

import org.bukkit.plugin.Plugin;
import java.util.List;
import java.util.UUID;
import java.util.ArrayList;
import org.bukkit.Bukkit;
import java.util.Calendar;
import java.util.Date;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import java.util.HashMap;
import eu.mclive.ChatLog.ChatLog;
import org.bukkit.command.CommandExecutor;

public class Chatreport implements CommandExecutor
{
    private ChatLog plugin;
    private HashMap<String, Long> lastReport;
    
    public Chatreport(final ChatLog plugin) {
        this.lastReport = new HashMap<String, Long>();
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender sender, final Command cmd, final String commandLabel, final String[] args) {
        final String player = sender.getName();
        if (cmd.getName().equalsIgnoreCase("chatreport")) {
            final Long last = this.lastReport.get(player);
            final Long cooldown = this.plugin.getConfig().getLong("reportCooldown") * 1000L;
            if (last != null && cooldown > 0L) {
                final Long now = System.currentTimeMillis();
                final Long until = last + cooldown;
                if (System.currentTimeMillis() <= until) {
                    final Long left = (until - now) / 1000L;
                    sender.sendMessage(this.plugin.messages.cooldown.replace("%seconds%", left.toString()));
                    return true;
                }
            }
            if (args.length == 0) {
                sender.sendMessage("§7§m                                                                     ");
                sender.sendMessage(this.plugin.messages.help.replace("%cmd%", "/" + commandLabel));
                sender.sendMessage("§7§m                                                                     ");
            }
            if (args.length >= 1) {
                final Date now2 = new Date();
                final Long timestamp = now2.getTime() / 1000L;
                final String server = this.plugin.getConfig().getString("server");
                final boolean mode = this.plugin.getConfig().getBoolean("minigames-mode");
                final int timeBack = this.plugin.getConfig().getInt("timeBack");
                if (!mode) {
                    final Calendar cal = Calendar.getInstance();
                    cal.set(12, cal.get(12) - timeBack);
                    this.plugin.pluginstart = cal.getTimeInMillis() / 1000L;
                }
                Bukkit.getScheduler().runTaskAsynchronously((Plugin)this.plugin, (Runnable)new Runnable() {
                    @Override
                    public void run() {
                        final List<String> users = new ArrayList<String>();
                        for (int i = 0; i < args.length; ++i) {
                            final String user = args[i];
                            final int messagesSent = Chatreport.this.plugin.sqlHandler.checkMessage(server, user, Chatreport.this.plugin.pluginstart, timestamp);
                            if (messagesSent >= 1) {
                                users.add(user);
                            }
                            else {
                                sender.sendMessage(Chatreport.this.plugin.messages.error.replace("%name%", user));
                            }
                        }
                        final String reportid = UUID.randomUUID().toString().replace("-", "");
                        if (users != null && users.size() > 0) {
                            Chatreport.this.plugin.sqlHandler.setReport(server, users, Chatreport.this.plugin.pluginstart, timestamp, reportid);
                            final String URL = Chatreport.this.plugin.getConfig().getString("URL");
                            sender.sendMessage(Chatreport.this.plugin.messages.url.replace("%url%", URL + reportid));
                            Chatreport.this.lastReport.put(player, System.currentTimeMillis());
                            Chatreport.this.plugin.incrementIssuedChatLogs();
                        }
                        else {
                            sender.sendMessage(Chatreport.this.plugin.messages.errorNotSaved);
                        }
                    }
                });
            }
        }
        return false;
    }
}
