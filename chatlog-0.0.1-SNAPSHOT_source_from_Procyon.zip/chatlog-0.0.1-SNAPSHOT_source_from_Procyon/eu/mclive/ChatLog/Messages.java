// 
// Decompiled by Procyon v0.5.36
// 

package eu.mclive.ChatLog;

import org.bukkit.ChatColor;
import java.io.IOException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.configuration.file.FileConfiguration;
import java.io.File;

public class Messages
{
    private ChatLog plugin;
    public String help;
    public String cmd_color;
    public String playername;
    public String seperator;
    public String help2;
    public String error;
    public String url;
    public String errorNotSaved;
    public String cooldown;
    private File file;
    private FileConfiguration cfg;
    
    public Messages(final ChatLog plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "messages.yml");
        (this.cfg = (FileConfiguration)YamlConfiguration.loadConfiguration(this.file)).addDefault("help", (Object)"&e%cmd% <playername> &7- &agets the Chatlog from a player.");
        this.cfg.addDefault("error", (Object)"&cNo messages found from %name%");
        this.cfg.addDefault("url", (Object)"&eURL: &a%url%");
        this.cfg.addDefault("errorNotSaved", (Object)"&cNo report saved");
        this.cfg.addDefault("cooldown", (Object)"§cYou have to wait %seconds% seconds.");
        this.cfg.options().copyDefaults(true);
        try {
            this.cfg.save(this.file);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        this.help = this.addcolors(this.cfg.getString("help"));
        this.error = this.addcolors(this.cfg.getString("error"));
        this.url = this.addcolors(this.cfg.getString("url"));
        this.errorNotSaved = this.addcolors(this.cfg.getString("errorNotSaved"));
        this.cooldown = this.addcolors(this.cfg.getString("cooldown"));
    }
    
    private String addcolors(String msg) {
        msg = ChatColor.translateAlternateColorCodes('&', msg);
        return msg;
    }
    
    public String help() {
        return this.addcolors(this.cfg.getString("help"));
    }
}
