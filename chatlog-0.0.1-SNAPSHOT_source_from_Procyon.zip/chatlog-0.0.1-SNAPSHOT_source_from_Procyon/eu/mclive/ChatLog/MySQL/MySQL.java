// 
// Decompiled by Procyon v0.5.36
// 

package eu.mclive.ChatLog.MySQL;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.DriverManager;
import org.bukkit.configuration.file.FileConfiguration;
import java.io.IOException;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.sql.Connection;
import eu.mclive.ChatLog.ChatLog;

public class MySQL
{
    private ChatLog plugin;
    private String host;
    private int port;
    private String user;
    private String password;
    private String database;
    private Connection conn;
    
    public MySQL(final ChatLog plugin) throws Exception {
        this.plugin = plugin;
        final File file = new File(plugin.getDataFolder(), "mysql.yml");
        final FileConfiguration cfg = (FileConfiguration)YamlConfiguration.loadConfiguration(file);
        final String db = "database.";
        cfg.addDefault(db + "host", (Object)"leer");
        cfg.addDefault(db + "port", (Object)3306);
        cfg.addDefault(db + "user", (Object)"leer");
        cfg.addDefault(db + "password", (Object)"leer");
        cfg.addDefault(db + "database", (Object)"leer");
        cfg.options().copyDefaults(true);
        try {
            cfg.save(file);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        this.host = cfg.getString(db + "host");
        this.port = cfg.getInt(db + "port");
        this.user = cfg.getString(db + "user");
        this.password = cfg.getString(db + "password");
        this.database = cfg.getString(db + "database");
        this.conn = this.openConnection();
    }
    
    public Connection openConnection() throws Exception {
        Class.forName("com.mysql.jdbc.Driver");
        final Connection conn = DriverManager.getConnection("jdbc:mysql://" + this.host + ":" + this.port + "/" + this.database, this.user, this.password);
        return conn;
    }
    
    public void refreshConnect() throws Exception {
        Class.forName("com.mysql.jdbc.Driver");
        this.conn = DriverManager.getConnection("jdbc:mysql://" + this.host + ":" + this.port + "/" + this.database, this.user, this.password);
    }
    
    public Connection getConnection() {
        try {
            if (!this.conn.isValid(1)) {
                System.out.println("[ChatLog] Lost MySQL-Connection! Reconnecting...");
                try {
                    this.conn = this.openConnection();
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        catch (SQLException e2) {
            e2.printStackTrace();
        }
        try (final PreparedStatement stmt = this.conn.prepareStatement("SELECT 1")) {
            stmt.executeQuery();
        }
        catch (SQLException e2) {
            System.out.println("[ChatLog] SELECT 1 - failled. Reconnecting...");
            try {
                this.conn = this.openConnection();
            }
            catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        return this.conn;
    }
    
    public boolean hasConnecion() {
        try {
            return this.conn != null || this.conn.isValid(1);
        }
        catch (SQLException e) {
            return false;
        }
    }
    
    public void queryUpdate(final String query) {
        final Connection connection = this.conn;
        try (final PreparedStatement st = connection.prepareStatement(query)) {
            st.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public void closeRessources(final ResultSet rs, final PreparedStatement st) {
        if (rs != null) {
            try {
                rs.close();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (st != null) {
            try {
                st.close();
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    public void closeConnection() {
        try {
            this.conn.close();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        finally {
            this.conn = null;
        }
    }
}
