// 
// Decompiled by Procyon v0.5.36
// 

package eu.mclive.ChatLog.MySQL;

import java.util.Iterator;
import java.util.List;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.util.UUID;
import java.sql.SQLException;
import org.bukkit.entity.Player;
import eu.mclive.ChatLog.ChatLog;

public class MySQLHandler
{
    private ChatLog plugin;
    private MySQL sql;
    
    public MySQLHandler(final MySQL mysql, final ChatLog plugin) {
        (this.sql = mysql).queryUpdate("CREATE TABLE IF NOT EXISTS messages (id int NOT NULL AUTO_INCREMENT, server varchar(100), name varchar(100), message varchar(400), timestamp varchar(50), PRIMARY KEY (id)) DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci");
        this.sql.queryUpdate("CREATE TABLE IF NOT EXISTS reportmessages (id int NOT NULL AUTO_INCREMENT, server varchar(100), name varchar(100), message varchar(400), timestamp varchar(50), reportid text, PRIMARY KEY (id)) DEFAULT CHARACTER SET utf8 DEFAULT COLLATE utf8_general_ci");
        this.plugin = plugin;
    }
    
    public void addMessage(final String server, final Player p, final String msg, final Long timestamp) {
        String name;
        if (this.plugin.getConfig().getBoolean("use-UUIDs")) {
            final UUID uuid = p.getUniqueId();
            name = uuid.toString().replace("-", "");
        }
        else {
            name = p.getName();
        }
        final Connection conn = this.sql.getConnection();
        try (final PreparedStatement st = conn.prepareStatement("INSERT INTO messages (server, name, message, timestamp) VALUES (?,?,?,?);")) {
            st.setString(1, server);
            st.setString(2, name);
            st.setString(3, msg);
            st.setLong(4, timestamp);
            st.executeUpdate();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public int checkMessage(final String server, final String p2, final Long pluginstart, final Long timestamp) {
        String name = null;
        if (this.plugin.getConfig().getBoolean("use-UUIDs")) {
            name = this.plugin.UUIDHandler.getUUID(p2);
        }
        else {
            name = p2;
        }
        final Connection conn = this.sql.getConnection();
        ResultSet rs = null;
        try (final PreparedStatement st = conn.prepareStatement("SELECT COUNT(*) AS count FROM messages WHERE server = ? && name = ? && timestamp >= ? && timestamp <= ?;")) {
            st.setString(1, server);
            st.setString(2, name);
            st.setLong(3, pluginstart);
            st.setLong(4, timestamp);
            rs = st.executeQuery();
            rs.first();
            return rs.getInt("count");
        }
        catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
    public void setReport(final String server, final List<String> users, final Long pluginstart, final Long timestamp, final String reportid) {
        final Connection conn = this.sql.getConnection();
        ResultSet rs = null;
        this.plugin.logger.info("ReportID: " + reportid);
        for (String user : users) {
            if (this.plugin.getConfig().getBoolean("use-UUIDs")) {
                user = this.plugin.UUIDHandler.getUUID(user);
            }
            try (final PreparedStatement st = conn.prepareStatement("SELECT * FROM messages WHERE server = ? && name = ? && timestamp >= ? && timestamp <= ?;")) {
                st.setString(1, server);
                st.setString(2, user);
                st.setLong(3, pluginstart);
                st.setLong(4, timestamp);
                rs = st.executeQuery();
                while (rs.next()) {
                    try (final PreparedStatement st2 = conn.prepareStatement("INSERT INTO reportmessages (server, name, message, timestamp, reportid) VALUES (?,?,?,?,?);")) {
                        st2.setString(1, server);
                        st2.setString(2, user);
                        st2.setString(3, rs.getString("message"));
                        st2.setLong(4, rs.getLong("timestamp"));
                        st2.setString(5, reportid);
                        st2.executeUpdate();
                    }
                    catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
            catch (SQLException e2) {
                e2.printStackTrace();
            }
        }
    }
    
    public void delete(final String server, final Long timestamp) {
        final Connection conn = this.sql.getConnection();
        try (final PreparedStatement st = conn.prepareStatement("DELETE FROM messages WHERE server = ? AND timestamp < ? ")) {
            st.setString(1, server);
            st.setLong(2, timestamp);
            final int rows = st.executeUpdate();
            if (rows > 0) {
                this.plugin.logger.info("Deleted " + rows + " old messages!");
            }
            else {
                this.plugin.logger.info("There were no old messages to delete.");
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
