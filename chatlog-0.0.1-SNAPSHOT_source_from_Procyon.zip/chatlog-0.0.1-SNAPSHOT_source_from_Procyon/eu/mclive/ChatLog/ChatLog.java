// 
// Decompiled by Procyon v0.5.36
// 

package eu.mclive.ChatLog;

import eu.mclive.ChatLog.update.UpdateUtil;
import java.util.Calendar;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import java.util.concurrent.Callable;
import eu.mclive.ChatLog.update.UpdateListener;
import org.bukkit.command.CommandExecutor;
import eu.mclive.ChatLog.Commands.Chatreport;
import org.bukkit.plugin.Plugin;
import java.util.Date;
import eu.mclive.ChatLog.bstats.Metrics;
import eu.mclive.ChatLog.MySQL.MySQLHandler;
import eu.mclive.ChatLog.MySQL.MySQL;
import java.util.logging.Logger;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

public class ChatLog extends JavaPlugin implements Listener
{
    public UUIDHandler UUIDHandler;
    public Logger logger;
    public MySQL sql;
    public Messages messages;
    public MySQLHandler sqlHandler;
    public Long pluginstart;
    private Metrics bstats;
    private Utils utils;
    private int issuedChatLogs;
    private int loggedMessages;
    
    public ChatLog() {
        this.logger = this.getLogger();
        this.pluginstart = null;
        this.issuedChatLogs = 0;
        this.loggedMessages = 0;
    }
    
    public void onEnable() {
        try {
            this.logger.info("Loading MySQL ...");
            this.sql = new MySQL(this);
            this.sqlHandler = new MySQLHandler(this.sql, this);
            this.startRefresh();
            this.logger.info("MySQL successfully loaded.");
        }
        catch (Exception e1) {
            this.logger.warning("Failled to load MySQL: " + e1.toString());
        }
        this.messages = new Messages(this);
        this.UUIDHandler = new UUIDHandler(this);
        this.utils = new Utils(this);
        this.setupConfig();
        final Date now = new Date();
        this.pluginstart = now.getTime() / 1000L;
        final boolean metrics = this.getConfig().getBoolean("metrics");
        if (metrics) {
            this.logger.info("Loading bStats ...");
            try {
                this.startBstats(new Metrics((Plugin)this));
                this.logger.info("bStats successfully loaded.");
            }
            catch (Exception e2) {
                this.logger.warning("Failed to load bStats.");
            }
        }
        this.cleanup();
        this.registerEvents();
        this.registerCommands();
        this.checkUpdates();
        this.logger.info("Plugin successfully started.");
    }
    
    public void onDisable() {
        this.logger.info("Plugin successfully stopped.");
    }
    
    private void setupConfig() {
        this.getConfig().options().copyDefaults(true);
        this.saveConfig();
    }
    
    private void registerCommands() {
        this.getCommand("chatreport").setExecutor((CommandExecutor)new Chatreport(this));
    }
    
    private void registerEvents() {
        if (this.getConfig().getBoolean("use-AsyncChatEvent")) {
            this.getServer().getPluginManager().registerEvents((Listener)new AsyncChatListener(this), (Plugin)this);
        }
        else {
            this.logger.info("Using NON-Async ChatEvent.");
            this.getServer().getPluginManager().registerEvents((Listener)new ChatListener(this), (Plugin)this);
        }
        this.getServer().getPluginManager().registerEvents((Listener)new UpdateListener(this), (Plugin)this);
    }
    
    private void startBstats(final Metrics bstats) {
        bstats.addCustomChart(new Metrics.SingleLineChart("issued_chatlogs", new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                final int value = ChatLog.this.issuedChatLogs;
                ChatLog.this.issuedChatLogs = 0;
                return value;
            }
        }));
        bstats.addCustomChart(new Metrics.SingleLineChart("logged_messages", new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                final int value = ChatLog.this.loggedMessages;
                ChatLog.this.loggedMessages = 0;
                return value;
            }
        }));
    }
    
    public void incrementIssuedChatLogs() {
        ++this.issuedChatLogs;
    }
    
    public void incrementLoggedMessages() {
        ++this.loggedMessages;
    }
    
    public void addMessage(final Player p, final String msg) {
        Bukkit.getScheduler().runTaskAsynchronously((Plugin)this, (Runnable)new Runnable() {
            @Override
            public void run() {
                final Date now = new Date();
                final Long timestamp = now.getTime() / 1000L;
                final String server = ChatLog.this.getConfig().getString("server");
                final String bypassChar = ChatLog.this.getConfig().getString("bypass-with-beginning-char");
                final String bypassPermission = ChatLog.this.getConfig().getString("bypass-with-permission");
                if (bypassChar.isEmpty() || (msg.startsWith(bypassChar) && !p.hasPermission(bypassPermission)) || !msg.startsWith(bypassChar)) {
                    ChatLog.this.sqlHandler.addMessage(server, p, msg, timestamp);
                }
            }
        });
    }
    
    public void cleanup() {
        final String server = this.getConfig().getString("server");
        final boolean doCleanup = this.getConfig().getBoolean("Cleanup.enabled");
        final int since = this.getConfig().getInt("Cleanup.since");
        if (doCleanup) {
            this.logger.info("Doing Cleanup...");
            final Calendar cal = Calendar.getInstance();
            final Date now = new Date();
            cal.setTime(now);
            cal.add(5, -since);
            final Long timestamp = cal.getTimeInMillis() / 1000L;
            Bukkit.getScheduler().runTaskAsynchronously((Plugin)this, (Runnable)new Runnable() {
                @Override
                public void run() {
                    ChatLog.this.sqlHandler.delete(server, timestamp);
                }
            });
        }
        else {
            this.logger.info("Skipping Cleanup because it is disabled.");
        }
    }
    
    public void startRefresh() {
        Bukkit.getScheduler().runTaskTimerAsynchronously((Plugin)this, (Runnable)new Runnable() {
            @Override
            public void run() {
                try {
                    ChatLog.this.sql.refreshConnect();
                }
                catch (Exception e) {
                    ChatLog.this.logger.warning("Failed to reload MySQL: " + e.toString());
                }
            }
        }, 200L, 36000L);
    }
    
    private void checkUpdates() {
        UpdateUtil.sendUpdateMessage((Plugin)this);
    }
    
    public Utils getUtils() {
        return this.utils;
    }
    
    public void setUtils(final Utils utils) {
        this.utils = utils;
    }
}
