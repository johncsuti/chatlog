// 
// Decompiled by Procyon v0.5.36
// 

package eu.mclive.ChatLog;

import org.bukkit.event.EventPriority;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerChatEvent;
import org.bukkit.event.Listener;

public class ChatListener implements Listener
{
    private ChatLog plugin;
    
    public ChatListener(final ChatLog plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerChat(final PlayerChatEvent e) {
        if (e.isCancelled()) {
            return;
        }
        this.plugin.getUtils().logMessage(e.getPlayer(), e.getMessage());
    }
}
