// 
// Decompiled by Procyon v0.5.36
// 

package eu.mclive.ChatLog;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class Utils
{
    private ChatLog plugin;
    
    public Utils(final ChatLog plugin) {
        this.plugin = plugin;
    }
    
    public void logMessage(final Player p, final String msg) {
        this.plugin.addMessage(p, ChatColor.stripColor(msg));
        this.plugin.incrementLoggedMessages();
    }
}
