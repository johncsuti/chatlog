// 
// Decompiled by Procyon v0.5.36
// 

package eu.mclive.ChatLog;

public class Permission
{
    public static final String UPDATE = "chatlog.update";
}
